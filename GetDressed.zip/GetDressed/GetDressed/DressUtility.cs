﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public static class DressUtility
    {
        public static readonly string Failstatus = "Fail";

        #region dress options
        public static readonly string boots = "boots";
        public static readonly string hats = "hats";
        public static readonly string socks = "socks";
        public static readonly string shirt = "shirt";
        public static readonly string jacket = "jacket";
        public static readonly string pants = "pants";
       
        public static readonly string Sandals = "Sandals";
        public static readonly string sunglasses = "sunglasses";
        public static readonly string Fail = "Fail";
        public static readonly string shorts = "shorts";

        public static readonly string PJ = "PJ";
        #endregion
    }

    public enum TemperatureType
    {
        HOT,
        COLD
    }
    public enum DressDescription
    {
        Takeoffpajamas = 1,
        Putonpants = 2,
        Putonshirt = 3,
        Putonsocks = 4,
        Putonfootwear = 5,
        Putonheadwear = 6,
        Putonjacket = 7,
        Leavehouse = 8
    }

}