﻿using GettingDressed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetDressed
{
    class Program
    {
        

        static void Main(string[] args)
        {
            try
            {
                #region Intialize Request

                Request request = new Request();
                request.Command = new List<int>();

                #endregion

                #region Hardcoded Request ideally should come from front end

                #region request1
                request.Command.Add(8);
                request.Command.Add(6);
                request.Command.Add(3);
                request.Command.Add(4);
                request.Command.Add(2);
                request.Command.Add(5);
                request.Command.Add(1);
                request.Command.Add(7);
                request.temp = TemperatureType.COLD;
                #endregion

                #region request 2 
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(4);
                //request.Command.Add(2);
                //request.Command.Add(1);
                //request.Command.Add(7);
                //request.temp = TemperatureType.HOT;
                #endregion

                #region request 3
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(6);
                //request.temp = TemperatureType.HOT;
                #endregion

                #region request 4
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(3);
                //request.temp = TemperatureType.HOT;
                #endregion

                #region request 5
                //request.Command.Add(8);
                //request.Command.Add(6);
                //request.Command.Add(3);
                //request.Command.Add(4);
                //request.Command.Add(2);
                //request.Command.Add(5);
                //request.Command.Add(7);
                //request.temp = TemperatureType.COLD;
                #endregion

                #region request 4
                //request.Command.Add(6);
                //request.temp = TemperatureType.COLD;
                #endregion

                #endregion

                #region Process Response

                Response response =GetDressedResponse(request);

                #endregion

                #region Display result
                Console.WriteLine("Your Request :" + response.TemperatureType + " Tempreture : ");
                Console.WriteLine(request.temp);
                foreach (int comm in request.Command)
                {
                    Console.WriteLine(comm);
                }

                Console.WriteLine("Your dress for " +response.TemperatureType + " Tempreture : ");
                foreach(int key in response.dresses.Keys)
                {
                    Console.WriteLine(response.dresses[key]);
                }
                Console.ReadLine();

                #endregion
            }
            catch (Exception ex)
            {
                //log exception
                Console.WriteLine("Fail");
                Console.ReadLine();
            }
        }

        static Response GetDressedResponse(Request request)
        {
            DressManager dressmanager;
            Response response;
            response = new Response();
            response.dresses = new Dictionary<int, string>();
            dressmanager = new DressManager();
            try
            {
                
                response = dressmanager.processresponse(request);
                response.TemperatureType = request.temp.ToString();
            }
            catch (Exception ex)
            {
                //log exception
                response.dresses.Add(-1, DressUtility.Failstatus);
            }
            return response;
        }


    }
}
