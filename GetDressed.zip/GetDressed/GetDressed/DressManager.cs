﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public class DressManager
    {
        #region Common Variables

        Dictionary<DressDescription, string> dresstowear;
        Dictionary<int, DressDescription> mappedcommands;
        Response response;

        #endregion

        public DressManager()
        {
            dresstowear = new Dictionary<DressDescription, string>();
            mappedcommands = new Dictionary<int, DressDescription>();
        }


        #region Process Response


        public Response processresponse(Request request)
        {
            response = new Response();
            response.dresses = new Dictionary<int, string>();
            try
            {
                dresstowear = GetData(request.temp);
                var values = (DressDescription[])Enum.GetValues(typeof(DressDescription));
                if (!ValidationManager.ValidateRequest(request))
                {
                    response.dresses.Add(0, DressUtility.Failstatus);
                    return response;

                }
                else
                {
                    foreach (int comm in request.Command)
                    {
                        if (mappedcommands.ContainsKey(comm) && dresstowear.ContainsKey(mappedcommands[comm]))
                        {
                            if (ValidationManager.ValidateResponse(response, (Array.IndexOf(values, mappedcommands[comm]))))
                            {
                                response.dresses.Add(Array.IndexOf(values, mappedcommands[comm]), dresstowear.First(x => x.Key == mappedcommands[comm]).Value);
                            }
                            else
                            {
                                response.dresses.Add(Array.IndexOf(values, mappedcommands[comm]) + 1, DressUtility.Failstatus);
                            }
                        }
                        else
                        {
                            if (mappedcommands[comm] != DressDescription.Leavehouse)
                            {
                                response.dresses.Add(comm, mappedcommands[comm].ToString());
                            }
                        }
                    }

                }
                if (ValidationManager.ValidateRules(response))
                {
                    if (request.temp == TemperatureType.HOT && !response.dresses.Any(x => x.Value == DressUtility.Failstatus))
                    {
                        response.dresses.Add(-1, DressDescription.Leavehouse.ToString());
                    }
                    else if (!response.dresses.Any(x => x.Value == DressUtility.Failstatus)
                        && (request.temp == TemperatureType.COLD && request.Command.Count > 7))
                    {
                        response.dresses.Add(-1, DressDescription.Leavehouse.ToString());
                    }
                    else
                    {
                        if (!response.dresses.Any(x => x.Value == DressUtility.Failstatus))
                        {
                            response.dresses.Add(-1, DressUtility.Failstatus);
                        }
                    }
                    return response;
                }
                response.dresses.Add(0, DressUtility.Failstatus);
            }
            catch (Exception ex)
            {
                //log exception
                response.dresses.Add(-1, DressUtility.Failstatus);
            }
            return response;
        }


        #endregion

        #region Get data 
        /// This would basically get data from either backend or service in real time Project 
        public Dictionary<DressDescription, string> GetData(TemperatureType temperatureType)
        {
            mappedcommands.Add(8, DressDescription.Takeoffpajamas);
            mappedcommands.Add(6, DressDescription.Putonpants);
            mappedcommands.Add(4, DressDescription.Putonshirt);
            mappedcommands.Add(3, DressDescription.Putonsocks);
            mappedcommands.Add(1, DressDescription.Putonfootwear);
            mappedcommands.Add(2, DressDescription.Putonheadwear);
            mappedcommands.Add(5, DressDescription.Putonjacket);
            mappedcommands.Add(7, DressDescription.Leavehouse);

            switch (temperatureType)
            {
                case TemperatureType.COLD:
                    dresstowear.Add(DressDescription.Putonfootwear, DressUtility.boots);
                    dresstowear.Add(DressDescription.Putonheadwear, DressUtility.hats);
                    dresstowear.Add(DressDescription.Putonsocks, DressUtility.socks);
                    dresstowear.Add(DressDescription.Putonshirt, DressUtility.shirt);
                    dresstowear.Add(DressDescription.Putonjacket, DressUtility.jacket);
                    dresstowear.Add(DressDescription.Putonpants, DressUtility.pants);
                    break;
                case TemperatureType.HOT:
                    dresstowear.Add(DressDescription.Putonfootwear, DressUtility.Sandals);
                    dresstowear.Add(DressDescription.Putonheadwear, DressUtility.sunglasses);
                    dresstowear.Add(DressDescription.Putonsocks, DressUtility.Fail);
                    dresstowear.Add(DressDescription.Putonshirt, DressUtility.shirt);
                    dresstowear.Add(DressDescription.Putonjacket, DressUtility.Fail);
                    dresstowear.Add(DressDescription.Putonpants, DressUtility.shorts);
                    break;
                default:
                    dresstowear.Add(DressDescription.Putonpants, DressUtility.PJ);
                    break;
            }
            return dresstowear;
        }

        #endregion
    }
}