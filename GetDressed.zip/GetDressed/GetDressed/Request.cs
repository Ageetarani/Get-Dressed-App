﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public class Request
    {
        public List<int> Command { get; set; }
        public TemperatureType temp { get; set; }
    }
}