﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public class Response
    {
        public Dictionary<int, string> dresses { get; set; }
        public bool ResultType { get; set; }

        public string TemperatureType { get; set; }
    }
    
}