﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GettingDressed
{
    public static class ValidationManager
    {
        public static bool ValidateRequest(Request request)
        {
            try
            {
                if (request == null || request.Command == null)
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public static bool ValidateResponse(Response response, int command = -1)
        {
            try
            {
                if (response != null && response.dresses != null && response.dresses.Count > 0)
                {
                    if (response.dresses.ContainsKey(command))
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public static bool ValidateRules(Response response)
        {
            try
            {
                if (
                    response.dresses.Any(x => x.Value == DressUtility.hats) &&
                    response.dresses.Any(x => x.Value == DressUtility.shirt) &&
                    (response.dresses.Keys.ToList().IndexOf(response.dresses.First(x => x.Value == DressUtility.hats).Key) <
                    response.dresses.Keys.ToList().IndexOf(response.dresses.First(x => x.Value == DressUtility.shirt).Key))
                    )
                {
                    return false;
                }
                else if (
                    response.dresses.Any(x => x.Value == DressUtility.boots) &&
                    response.dresses.Any(x => x.Value == DressUtility.pants) &&
                    (response.dresses.Keys.ToList().IndexOf(response.dresses.First(x => x.Value == DressUtility.boots).Key) <
                    response.dresses.Keys.ToList().IndexOf(response.dresses.First(x => x.Value == DressUtility.pants).Key))
                    )
                {
                    return false;
                }
                else if (response.dresses.Any(x => x.Value == DressUtility.Sandals) &&
                    response.dresses.Any(x => x.Value == DressUtility.shorts) &&
                    (response.dresses.Keys.ToList().IndexOf(response.dresses.First(x => x.Value == DressUtility.Sandals).Key) <
                    response.dresses.Keys.ToList().IndexOf(response.dresses.First(x => x.Value == DressUtility.shorts).Key)))
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
    }
}